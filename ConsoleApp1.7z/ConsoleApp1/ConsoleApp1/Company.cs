﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace ConsoleApp1
{
    [Serializable, XmlRoot("result")]
    public class Company
    {
        public string razaoSocial { get; set; }
        [XmlArray("enderecos")]
        [XmlArrayItem("endereco", typeof(CompanyAddress))]
        public List<CompanyAddress> address { get; set; }
        [XmlArray("enderecos")]
        [XmlArrayItem("endereco")]
        public List<Street> street { get; set; }

    }
}
