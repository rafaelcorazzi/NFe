﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace ConsoleApp1
{
    [Serializable, XmlRoot("logradouro")]
    public class Street
    {
       
        [System.Xml.Serialization.XmlElement("Nome")]
        public string name { get; set; }
    }
}
