﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace ConsoleApp1
{
    [Serializable()]
    public class CompanyAddress
    {
        [System.Xml.Serialization.XmlElement("bairro")]
        public string district { get; set; }
        [XmlElement("logradouro", typeof(Street))]
        public Street logradouro
    }
}
