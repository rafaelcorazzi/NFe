﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Xml;

namespace ConsoleApp1
{
    public class SoapParse
    {
        public static String soapSerasa(string Cnpj)
        {
            String result = String.Empty;
            MemoryStream stream = new MemoryStream(); // The writer closes this for us

            using (XmlTextWriter writer = new XmlTextWriter(stream, Encoding.UTF8))
            {




                writer.WriteStartDocument();
                writer.WriteStartElement("ConsultarPJ");
                writer.WriteStartElement("parameters");
                writer.WriteStartElement("RetornoPJ");
                
                writer.WriteElementString("cnae", "true");
                writer.WriteElementString("cnpj", "false");
                writer.WriteElementString("dataAbertura", "true");
                writer.WriteElementString("endereco", "true");
                writer.WriteElementString("funcionarios", "true");
                writer.WriteElementString("nomeFantasia", "true");
                writer.WriteElementString("razaoSocial", "true");
                writer.WriteElementString("representanteLegal", "false");
                writer.WriteElementString("situacaoCadastral", "HISTORICO");
                writer.WriteElementString("telefone", "true");
                writer.WriteEndElement();
                writer.WriteElementString("cnpj", Cnpj);
                writer.WriteEndElement();
                writer.WriteEndElement();
                writer.WriteEndDocument();
                writer.Flush();
                writer.Flush();

                StreamReader reader = new StreamReader(stream, Encoding.UTF8, true);
                stream.Seek(0, SeekOrigin.Begin);

                result += reader.ReadToEnd();


            }

            return result;
        }
    }
}
