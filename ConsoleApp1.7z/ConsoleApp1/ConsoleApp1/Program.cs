﻿using SoapHttpClient;
using SoapHttpClient.Enums;
using SoapHttpClient.Extensions;
using System;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Schema;
using System.Xml.Serialization;

namespace ConsoleApp1
{
    class Program
    {
        public static T Deserialize<T>(string input) where T : class
        {
            System.Xml.Serialization.XmlSerializer ser = new System.Xml.Serialization.XmlSerializer(typeof(T));

            using (StringReader sr = new StringReader(input))
            {
                return (T)ser.Deserialize(sr);
            }
        }
        static void Main(string[] args)
        {
            string body = File.ReadAllText(@"C:\temp\ConsoleApp1\ConsoleApp1\serasa.xml"); //SoapParse.soapSerasa("05150060000104");

            XmlDocument result = new XmlDocument();
            result.LoadXml(RequestWebService("https://sitenet.serasa.com.br/experian-data-licensing-ws/dataLicensingService", body, "http://services.experian.com.br/DataLicensing/DataLicensingService/ConsultarPJ"));
            XmlNamespaceManager namespaces = new XmlNamespaceManager(result.NameTable);
            namespaces.AddNamespace("ns2", "http://services.experian.com.br/DataLicensing/DataLicensingService/");
            XmlNodeList retEnvEvento = result.SelectNodes("descendant::ns2:ConsultarPJResponse", namespaces);

            string retonro = retEnvEvento.Item(0).InnerXml;

           
            XmlReader reader = XmlReader.Create(@"C:\temp\comp.xml");
            XmlSchemaSet schemaSet = new XmlSchemaSet();
            XmlSchemaInference schema = new XmlSchemaInference();

            schemaSet = schema.InferSchema(reader);


            foreach (XmlSchema s in schemaSet.Schemas())
            {
                XmlWriter xsdFile = new XmlTextWriter(@"C:\temp\some_xsd.xsd", System.Text.Encoding.UTF8);
                s.Write(xsdFile);
                xsdFile.Close();
            }

            byte[] data = Encoding.ASCII.GetBytes(retonro);
            MemoryStream stm = new MemoryStream(data, 0, data.Length);
            XmlSerializer deserializer = new XmlSerializer(typeof(Company), new XmlRootAttribute("result"));
            object obj = deserializer.Deserialize(stm);
            Company XmlData = (Company)obj;
        

            //Company resultingMessage = (Company)serializer.Deserialize(rdr);
            Console.ReadLine();
        }
        private CookieContainer cookies = new CookieContainer();
        public static string RequestWebService(string wsURL, string param, string action)
        {

            Uri urlpost = new Uri(wsURL);
            HttpWebRequest httpPostConsultaNFe = (HttpWebRequest)HttpWebRequest.Create(urlpost);

            string postConsultaComParametros = param;
            byte[] buffer2 = Encoding.ASCII.GetBytes(postConsultaComParametros);

            //httpPostConsultaNFe.CookieContainer = cookies;
            httpPostConsultaNFe.Timeout = 300000;
            httpPostConsultaNFe.ContentType = "application/soap+xml; charset=utf-8; action=" + action;
            httpPostConsultaNFe.Method = "POST";
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls;
            httpPostConsultaNFe.ProtocolVersion = HttpVersion.Version10;
            httpPostConsultaNFe.ContentLength = buffer2.Length;



            Stream PostData = httpPostConsultaNFe.GetRequestStream();
            PostData.Write(buffer2, 0, buffer2.Length);
            PostData.Close();

            HttpWebResponse responsePost = (HttpWebResponse)httpPostConsultaNFe.GetResponse();
            Stream istreamPost = responsePost.GetResponseStream();
            StreamReader strRespotaUrlConsultaNFe = new StreamReader(istreamPost, System.Text.Encoding.UTF8);

            return strRespotaUrlConsultaNFe.ReadToEnd();


        }
        static  void CallEchoServiceAsync()
        {
            var ns = XNamespace.Get("http://services.experian.com.br/DataLicensing/DataLicensingService/");
            var endpoint = new Uri("https://sitenet.serasa.com.br/experian-data-licensing-ws/dataLicensingService");
            string body = File.ReadAllText(@"C:\temp\ConsoleApp1\ConsoleApp1\serasa.xml"); //SoapParse.soapSerasa("05150060000104");
            var actualEnvelope = XElement.Parse(body);
           // var body = new XElement(xml);

            using (var soapClient = new SoapClient())
            {
                var result =
                   soapClient.Post(
                          endpoint: endpoint,
                          soapVersion: SoapVersion.Soap11,
                          body: actualEnvelope,
                          action: "http://services.experian.com.br/DataLicensing/DataLicensingService/ConsultarPJ");

                Console.WriteLine(result.Content);
                Console.ReadLine();
            }
        }
        static async Task consulta()
        {

            var url = "https://sitenet.serasa.com.br/experian-data-licensing-ws/dataLicensingService";

            string body = SoapParse.soapSerasa("05150060000104");

            var actualEnvelope = XElement.Parse(body);

            var ns = XNamespace.Get("http://services.experian.com.br/DataLicensing/DataLicensingService/");
            var endpoint = new Uri(url);
            //var body = new XElement(ns.GetName("getAllObjects"));

            using (var soapClient = new SoapClient())
            {
                var result = soapClient.PostAsync(
                    endpoint: endpoint,
                    soapVersion: SoapVersion.Soap11,
                    body: actualEnvelope,
                    headers: null,
                    action: "http://services.experian.com.br/DataLicensing/DataLicensingService/ConsultarPJ");
                HttpResponseMessage message =  result.Result;

                Console.WriteLine(message);
            }


            Console.WriteLine("Hello World!");
            Console.ReadLine();
        }
    }
}

public class ContentTypeChangingHandler : DelegatingHandler
{
    public ContentTypeChangingHandler(HttpMessageHandler innerHandler) : base(innerHandler) { }

    protected async override Task<HttpResponseMessage> SendAsync(
      HttpRequestMessage request,
      CancellationToken cancellationToken)
    {
        request.Content.Headers.ContentType = MediaTypeHeaderValue.Parse("text/xml; charset=utf-8");
        return await base.SendAsync(request, cancellationToken);
    }
}
